/**
 * <copyright>
 * </copyright>
 *
 */
package org.eclipse.xtext.example.domainmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Structural Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.example.domainmodel.DomainmodelPackage#getStructuralFeature()
 * @model
 * @generated
 */
public interface StructuralFeature extends Feature
{
} // StructuralFeature
